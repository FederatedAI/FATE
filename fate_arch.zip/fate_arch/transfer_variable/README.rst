Transfer Variable
=================

Generate auth conf
------------------

.. code-block:: bash

   python fate_arch/transfer_variable/scripts/generate_auth_conf.py federatedml federatedml/transfer_variable/auth_conf
