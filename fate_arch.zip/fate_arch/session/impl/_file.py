class Path(object):
    def __init__(self, path, path_type):
        self.path = path
        self.path_type = path_type
