USE fate_flow;
ALTER TABLE t_queue ADD f_frequency INT DEFAULT 0;