import abc


class AddressABC(metaclass=abc.ABCMeta):
    ...

