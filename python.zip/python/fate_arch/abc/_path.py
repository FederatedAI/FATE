from abc import ABCMeta


class PathABC(metaclass=ABCMeta):
    ...
