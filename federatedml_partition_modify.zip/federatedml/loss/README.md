# Loss
Loss Module now is only used in SecureBoost, it supports the following loss functions:
* Binary Classification: sigmoid-cross-entropy loss function
* Multi Classification: softmax-cross-entropy loss function
* Regression:  
  1. least-squared-error loss function
  2. least-absolutely-error loss function
  3. huber loss function
  4. fair loss function
  5. log-cosh loss function
  6. tweedie loss function
  



