#
#  Copyright 2019 The FATE Authors. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import bisect

import numpy as np

from federatedml.feature.binning.quantile_binning import QuantileBinningTool
from federatedml.feature.homo_feature_binning import homo_binning_base
from federatedml.param.feature_binning_param import HomoFeatureBinningParam
from federatedml.util import LOGGER


class Server(homo_binning_base.Server):
    def __init__(self, params=None, abnormal_list=None):
        super().__init__(params, abnormal_list)

    def fit(self):
        self.get_min_max()
        self.query_values()


class Client(homo_binning_base.Client):
    def __init__(self, params: HomoFeatureBinningParam = None, abnormal_list=None, allow_duplicate=False):
        super().__init__(params, abnormal_list)
        self.allow_duplicate = allow_duplicate
        self.query_points = {}
        self.global_ranks = {}
        self.total_count = 0

    def fit(self, data_inst):
        if self.total_count > 0:
            return
        quantile_tool = QuantileBinningTool(param_obj=self.params,
                                            abnormal_list=self.abnormal_list,
                                            allow_duplicate=self.allow_duplicate)
        quantile_tool.set_bin_inner_param(self.bin_inner_param)

        summary_table = quantile_tool.fit_summary(data_inst)

        self.get_min_max(data_inst)
        for idx, col_name in enumerate(self.bin_inner_param.bin_names):
            max_value = self.max_values[idx]
            min_value = self.min_values[idx]
            self.query_points[col_name] = np.linspace(min_value, max_value, self.params.sample_bins)
        self.global_ranks = self.query_values(summary_table, self.query_points)
        self.total_count = data_inst.count()

    def fit_split_points(self, data_instances):
        self.fit(data_instances)

        percent_value = 1.0 / self.bin_num

        # calculate the split points
        percentile_rate = [i * percent_value for i in range(1, self.bin_num)]
        percentile_rate.append(1.0)

        query_ranks = [int(x * self.total_count) for x in percentile_rate]
        self._query(query_ranks)
        return self.bin_results.all_split_points

    def _query(self, ranks):
        for col_name in self.bin_inner_param.bin_names:
            query_res = []
            query_values = self.query_points[col_name]
            global_ranks = self.global_ranks[col_name]
            LOGGER.debug(f"query_values: {query_values}, global_ranks: {global_ranks}")
            for rank in ranks:
                idx = bisect.bisect_left(global_ranks, rank)
                if idx >= len(global_ranks) - 1:
                    approx_value = query_values[-1]
                    query_res.append(approx_value)
                else:
                    approx_value = query_values[idx] + (query_values[idx + 1] - query_values[idx]) * \
                                   ((rank - global_ranks[idx]) /
                                    (global_ranks[idx + 1] - global_ranks[idx]))
                    query_res.append(approx_value)
                LOGGER.debug(f"rank: {rank}, idx: {idx}, approx_value: {approx_value}")

            self.bin_results.put_col_split_points(col_name, query_res)
