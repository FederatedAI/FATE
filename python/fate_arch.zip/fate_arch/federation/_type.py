from enum import Enum


class FederationEngine(object):
    EGGROLL = 'EGGROLL'
    RABBITMQ = 'RABBITMQ'
    STANDALONE = 'STANDALONE'
    PULSAR = 'PULSAR'
