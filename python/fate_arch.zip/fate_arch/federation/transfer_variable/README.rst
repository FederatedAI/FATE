Transfer Variable
=================

Generate auth conf
------------------

.. code-block:: bash

   python fate_arch/federation/transfer_variable/scripts/generate_auth_conf.py federatedml/transfer_variable federatedml/transfer_variable/auth_conf
